package main;

import java.util.ArrayList;
import model.shapeManipulation.AllShapes;
import java.util.List;
import controller.Jpaintctrlr;
import controller.PaintCtrlr;
import model.persistence.APPstate;
import model.shapeManipulation.ApplyShape;
import controller.commands.SHAPES;
import model.shapeManipulation.DrawShape;
import model.shapeManipulation.ObserverShp;
import model.shapeManipulation.ShapeSUB;
import model.shapeManipulation.ManageList;
import model.shapeManipulation.MasterList;
import view.gui.ClickHandler;
import model.shapeManipulation.SelectedList;
import view.gui.Gui;
import view.gui.GuiWindow;
import view.gui.PaintOnCanvas;
import view.interfaces.PaintGUIConsole;
import view.interfaces.InterfaceMode;

public class DriverCode {
    public static void main(String[] args){
    	
    	PaintOnCanvas canvas = new PaintOnCanvas();
    	
        PaintGUIConsole guiWindow = new GuiWindow(canvas);
        InterfaceMode uiModule = new Gui(guiWindow);
        APPstate appState = new APPstate(uiModule);
        Jpaintctrlr controller = new PaintCtrlr(uiModule, appState);
        controller.setup();
        
        canvas.addMouseListener(new ClickHandler());
        ClickHandler.stateGrabber(appState);
        SHAPES.grabEndpoint(appState);
        
        final List<ApplyShape> master = new ArrayList<ApplyShape>();
        ShapeSUB masterList = new MasterList(master);
        ObserverShp observer = new DrawShape(canvas);
        masterList.registerObserver(observer);
        
        final List<ApplyShape> selected = new ArrayList<ApplyShape>();
        AllShapes selectedList = new SelectedList(selected);
              
        final List<ApplyShape> clipBoard = new ArrayList<ApplyShape>();
        AllShapes clipBoardList = new SelectedList(clipBoard);
        
        ManageList listManager = new ManageList(masterList, selectedList, clipBoardList);
        ManageList.getManager(listManager);
    }
}
