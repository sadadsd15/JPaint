package view.interfaces;

import view.EventName;

import javax.swing.*;

public interface PaintGUIConsole {
    JButton getButton(EventName eventName);
}
