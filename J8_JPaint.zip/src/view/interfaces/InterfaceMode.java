package view.interfaces;

import view.EventName;

public interface InterfaceMode {
    void addEvent(EventName eventName, IEventCallback command);
    <T> T getDialogResponse(IDialogChoice dialogChoice);
}
