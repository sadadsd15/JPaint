package view.gui;

import javax.swing.JComponent;
import java.awt.*;

public class PaintOnCanvas extends JComponent {

    public Graphics2D getGraphics2D() {
        return (Graphics2D)getGraphics();
    }
}
