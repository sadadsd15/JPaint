package model.shapeManipulation;

import java.util.List;

public class ClipBoardList implements AllShapes {
	
	public List<ApplyShape> shapeList;

	public ClipBoardList(List<ApplyShape> shapeList) {
		this.shapeList = shapeList; }

	@Override
	public void addShape(ApplyShape shape) {
		shapeList.add(shape);		
	}

	@Override
	public void removeShape(ApplyShape shape) {
		shapeList.remove(shape);		
	}

	@Override
	public List<ApplyShape> grabList() {
		return shapeList;
	}
}
