package model.shapeManipulation;


import java.util.ArrayList;
import java.util.List;

public class MasterList implements ShapeSUB, AllShapes {
	
	private List<ObserverShp> observers = new ArrayList<ObserverShp>();
	
	public List<ApplyShape> shapeList;

	public MasterList(List<ApplyShape> shapeList) {
		this.shapeList = shapeList; 
	}
			
	@Override
	public void addShape(ApplyShape shape) {
		shapeList.add(shape); 		
		notifyObservers();	
	}
	
	@Override
	public void removeShape(ApplyShape shape) {
		shapeList.remove(shape);
		notifyObservers();	
	}
	
	@Override
	public void registerObserver(ObserverShp observer) {
		observers.add(observer);	
	}


	@Override
	public void notifyObservers() {
		for(ObserverShp observer: observers) {
			observer.update();			
		}
	}
	
	@Override
	public List<ApplyShape> grabList() {
		return shapeList;
	}
}
