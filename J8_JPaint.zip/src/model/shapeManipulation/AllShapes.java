package model.shapeManipulation;

import java.util.List;

public interface AllShapes {

	public void addShape(ApplyShape shape);
	
	public void removeShape(ApplyShape shape);
	
	public List<ApplyShape> grabList();
}
