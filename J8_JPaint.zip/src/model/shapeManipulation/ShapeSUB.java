package model.shapeManipulation;

public interface ShapeSUB {
	
	void registerObserver(ObserverShp observer);
	
	void notifyObservers();
	
	void addShape(ApplyShape shape);
	
	void removeShape(ApplyShape shape);
	
}
