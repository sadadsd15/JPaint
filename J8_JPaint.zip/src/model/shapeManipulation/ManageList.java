package model.shapeManipulation;

public class ManageList {
	
	private static ShapeSUB masterList;
	private static AllShapes selectedList;
	private static AllShapes clipBoard;
	
	static ManageList manager;

	public ManageList(ShapeSUB masterList, AllShapes selectedList, AllShapes clipBoard) {
		ManageList.masterList = masterList;
		ManageList.selectedList = selectedList;
		ManageList.clipBoard = clipBoard;
	}
	
	public static ShapeSUB getMaster() {
		return masterList;
	}
	
	public static AllShapes getSelected() {
		return selectedList;
	}
	
	public static AllShapes getClipBoard() {
		return clipBoard;
	}
	
	public static void getManager(ManageList thisManager) {
		manager = thisManager;
	}
}
