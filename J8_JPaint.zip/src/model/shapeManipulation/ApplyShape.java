package model.shapeManipulation;

import java.awt.Color;

import controller.commands.CommandHistory;
import controller.commands.ICommand;
import controller.commands.IUndoable;
import model.ShapeConfiguration;
import model.ShapeShadingType;
import model.ShapeType;
import view.gui.CustomPair;

public class ApplyShape implements ICommand, IUndoable {
	
	ApplyShape shape;
	Color primaryColor;
	Color secondaryColor;
	ShapeType shapeType;	
	ShapeShadingType shadingType;
	public ShapeConfiguration shapeConfig;
	public CustomPair startingPair;
	public CustomPair endingPair;
	public int height;
	public int width;	
	int X;
	int Y;		
	
	public ApplyShape(int X, int Y, CustomPair startingPair, CustomPair endingPair,
                      int height, int width, ShapeConfiguration shapeConfig){
		this.X = X;
		this.Y = Y;
		this.startingPair = startingPair;
		this.endingPair = endingPair;
		this.height = height;
		this.width = width;
		this.shapeConfig = shapeConfig;		
		this.shapeType = shapeConfig.shapeType;
		this.primaryColor = shapeConfig.primaryColor.getColor();
		this.secondaryColor = shapeConfig.secondaryColor.getColor();
		this.shadingType = shapeConfig.shadingType;		}

	@Override
	public void run()  {
		shape = new ApplyShape(X, Y, startingPair, endingPair, height, width, shapeConfig);
		ManageList.getMaster().addShape(shape);
		CommandHistory.add(this);		
		}		

	@Override
	public void undo() {		
		ManageList.getMaster().removeShape(shape);
	}

	@Override
	public void redo() {
		ManageList.getMaster().addShape(shape);
	}
}

