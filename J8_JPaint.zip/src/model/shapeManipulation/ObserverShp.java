package model.shapeManipulation;

public interface ObserverShp {
	void update();	
}
