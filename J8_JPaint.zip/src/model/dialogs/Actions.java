package model.dialogs;

import model.interfaces.IApplicationState;
import view.interfaces.IDialogChoice;

public class Actions implements IDialogChoice<model.Actions> {
    private final IApplicationState applicationState;

    public Actions(IApplicationState applicationState) {

        this.applicationState = applicationState;
    }

    @Override
    public String getDialogTitle() {
        return "Start and End Point Mode";
    }

    @Override
    public String getDialogText() {
        return "Select a shading type from the menu below:";
    }

    @Override
    public model.Actions[] getDialogOptions() {
        return model.Actions.values();
    }

    @Override
    public model.Actions getCurrentSelection() {
        return applicationState.getActiveStartAndEndPointMode();
    }
}
