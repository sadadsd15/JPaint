package model.interfaces;

import model.ColorAdapter;
import model.ShapeShadingType;
import model.ShapeType;
import model.Actions;

public interface IApplicationState {
    void setActiveShape();

    void setActivePrimaryColor();

    void setActiveSecondaryColor();

    void setActiveShadingType();

    void setActiveStartAndEndPointMode();

    ShapeType getActiveShapeType();

    ColorAdapter getActivePrimaryColor();

    ColorAdapter getActiveSecondaryColor();

    ShapeShadingType getActiveShapeShadingType();

    Actions getActiveStartAndEndPointMode();
}
