package model;

public enum Actions {
    DRAW,
    SELECT,
    MOVE
}
