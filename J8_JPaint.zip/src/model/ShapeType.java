package model;

public enum ShapeType {
    ELLIPSE,
    RECTANGLE,
    TRIANGLE, 
    CIRCLE
}
