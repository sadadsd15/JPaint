package controller.commands;

import model.ShapeConfiguration;
import model.shapeManipulation.ApplyShape;
import model.shapeManipulation.ManageList;
import view.gui.CustomPair;

public class COPY implements ICommand {
	
	@Override
	public void run() {
		
		ManageList.getClipBoard().grabList().clear();
		
		
		for (ApplyShape shape : ManageList.getSelected().grabList()) {
			
			int newStartX = shape.startingPair.X + 100;
			int newStartY = shape.startingPair.Y + 100;
			CustomPair newStartPair = new CustomPair(newStartX, newStartY);
			
			int newEndX = shape.endingPair.X + 100;
			int newEndY = shape.endingPair.Y + 100;
			CustomPair newEndPair = new CustomPair (newEndX, newEndY);
			
			int newHeight = shape.height;
			int newWidth = shape.width;
			
			int newX = Math.min(newStartX, newEndX);
			int newY = Math.min(newStartY, newEndY);
			
			ShapeConfiguration newConfig = shape.shapeConfig;
			
			ApplyShape copiedShape = new ApplyShape(newX, newY, newStartPair, newEndPair,
												newHeight, newWidth, newConfig);
			
			ManageList.getClipBoard().addShape(copiedShape);
			
			
		}

	}
		
	

}
