package controller.commands;
import java.util.Stack;
public class CommandHistory {
	
		private static final Stack<IUndoable> undoStack = new Stack<IUndoable>();
		private static final Stack<IUndoable> redoStack = new Stack<IUndoable>();

		public static void add(IUndoable cmd) {
			undoStack.push(cmd);
			redoStack.clear();
		}

		// Defining a function to undo actions
		public static boolean undo() {			
			
			boolean Outcome = !undoStack.empty();
			if (Outcome) {
				IUndoable c = undoStack.pop();
				
				redoStack.push(c);
				c.undo();
			}
			return Outcome;
		}

		// Defining a function to redo actions
		public static boolean redo() {
			
			boolean Outcome = !redoStack.empty();
			
			if (Outcome) {
				IUndoable c = redoStack.pop();
				undoStack.push(c);
				c.redo();				
			}
			return Outcome;
		}

		// Test 1
		IUndoable topUndoCommand() {
			if (undoStack.empty())
				return null;
			else
				return undoStack.peek();
		}
		
		// Test 2
		IUndoable topRedoCommand() {
			if (redoStack.empty())
				return null;
			else
				return redoStack.peek();
		}
	}



