package controller.commands;

public class UNDO implements ICommand {

	@Override
	public void run() {
		CommandHistory.undo();
	}
}
