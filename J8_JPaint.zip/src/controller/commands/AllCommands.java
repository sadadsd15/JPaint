package controller.commands;

import model.ShapeConfiguration;
import model.shapeManipulation.ApplyShape;
import view.gui.CustomPair;

public class AllCommands {
	
	
	public static ICommand DRAW(int X, int Y, CustomPair startingPair, CustomPair endingPair,
								int height, int width, ShapeConfiguration shapeConfig) {
		return new ApplyShape(X, Y, startingPair, endingPair, height, width, shapeConfig);
	}
	
	public static ICommand SELECT(CustomPair startPair, CustomPair endPair) {
		return new SELECT(startPair, endPair);
	}
	
	
	public static ICommand MOVE(CustomPair startingPair) {
		return new MOVE(startingPair);
	}
}
