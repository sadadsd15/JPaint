package controller.commands;

import java.io.IOException;

import model.ShapeConfiguration;
import model.Actions;
import view.gui.CustomPair;
import model.persistence.APPstate;

public class SHAPES {
	private static APPstate appState;
	private static ICommand command;
	
	public static void commandRunner(int X, int Y, CustomPair startingPair, 
										CustomPair endingPair, int height, int width, 
										ShapeConfiguration shapeConfig) 
												throws IOException {

		//ICommand command = null;
		Actions endPoint = appState.getActiveStartAndEndPointMode();
		
		switch(endPoint) {

		case DRAW:
			command = AllCommands.DRAW(X, Y, startingPair, endingPair, height, width, shapeConfig);
			break;
		case SELECT:
			command = AllCommands.SELECT(startingPair, endingPair);
			break;
		case MOVE:
			command = AllCommands.MOVE(startingPair);
			break;
		
		default:
			throw new IOException("No such command"); 
			}

		command.run();
		}
	
	public static void grabEndpoint(APPstate state) {
		appState = state;		
	}
}


