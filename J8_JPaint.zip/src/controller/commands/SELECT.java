package controller.commands;

import model.shapeManipulation.ApplyShape;
import model.shapeManipulation.ManageList;
import model.shapeManipulation.MasterList;

import view.gui.CustomPair;

public class SELECT implements ICommand {
	
	CustomPair boundStart;
	CustomPair boundEnd;
	static SELECT boundingBox;
	
	public SELECT(CustomPair boundStart, CustomPair boundEnd) {
		this.boundStart = boundStart;
		this.boundEnd = boundEnd;
	}
	
	public static void selectCommand(CustomPair boundStart, CustomPair boundEnd) {
		
		ManageList.getSelected().grabList().clear();
		
		 boundingBox = new SELECT(boundStart, boundEnd);
		
		for (ApplyShape shape : ((MasterList) ManageList.getMaster()).grabList()) {
				if (boundingBox.boundStart.X < shape.startingPair.X && boundingBox.boundEnd.X > shape.endingPair.X
						&& boundingBox.boundStart.Y < shape.startingPair.Y && boundingBox.boundEnd.Y > shape.endingPair.Y) {
					ManageList.getSelected().addShape(shape);
				}				
			}
		}	

	@Override
	public void run(){
		
		
		selectCommand(boundStart, boundEnd);
	}
	
	
	
	public static SELECT getBoundingBox() {
		
		return boundingBox;
	}	
}