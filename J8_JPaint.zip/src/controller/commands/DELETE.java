package controller.commands;

import java.util.ArrayList;

import model.shapeManipulation.ApplyShape;
import model.shapeManipulation.ManageList;

public class DELETE implements ICommand, IUndoable {
	
	private static ApplyShape shapeToDelete;
	private static ArrayList<ApplyShape> deleteShapes = new ArrayList<ApplyShape>();
	
	@Override
	public void run() {
		deleteShapes.clear();
		for (ApplyShape shape : ManageList.getSelected().grabList()) {
			shapeToDelete = shape;
			ManageList.getMaster().removeShape(shapeToDelete);
			deleteShapes.add(shapeToDelete);
			
			CommandHistory.add(this);
			}	
	}

	@Override
	public void undo() {
		for (ApplyShape shape : deleteShapes) {
		ManageList.getMaster().addShape(shape);
		}
	}

	@Override
	public void redo() {
		for (ApplyShape shape : deleteShapes) {
		ManageList.getMaster().removeShape(shape);
		}
	}
}
