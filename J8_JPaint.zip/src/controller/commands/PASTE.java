package controller.commands;

import java.util.ArrayList;
import java.util.List;

import model.shapeManipulation.ApplyShape;
import model.shapeManipulation.ManageList;
import model.shapeManipulation.MasterList;

public class PASTE implements ICommand, IUndoable {
	
	static List<ApplyShape> clipBoard;
	static MasterList master;
	static ApplyShape shapeToPaste;
	
	private static ArrayList<ApplyShape> pastedShapes = new ArrayList<ApplyShape>();
	
	@Override
	public void run() {
		for (ApplyShape shape : ManageList.getClipBoard().grabList()) {
			shapeToPaste = shape;
			pastedShapes.add(shape);
			ManageList.getMaster().addShape(shapeToPaste);
			CommandHistory.add(this);		
		}
		ManageList.getClipBoard().grabList().clear();
	}

	@Override
	public void undo() {
		for(ApplyShape shapeToPaste : pastedShapes) {
		ManageList.getMaster().removeShape(shapeToPaste);
		}
	}

	@Override
	public void redo() {
		for (ApplyShape shapeToPaste : pastedShapes) {
		ManageList.getMaster().addShape(shapeToPaste);
		}
	}	
}
