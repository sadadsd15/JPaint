package controller.commands;

public class REDO implements ICommand {
	
	@Override
	public void run()  {
		CommandHistory.redo();
	}
}
