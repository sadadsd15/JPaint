package controller;

public interface Jpaintctrlr {
    void setup();
}
