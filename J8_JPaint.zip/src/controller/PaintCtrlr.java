package controller;

import controller.commands.COPY;
import controller.commands.DELETE;
import controller.commands.PASTE;
import controller.commands.REDO;
import controller.commands.UNDO;
import model.interfaces.IApplicationState;
import view.EventName;
import view.interfaces.InterfaceMode;

public class PaintCtrlr implements Jpaintctrlr {
    private final InterfaceMode uiModule;
    private final IApplicationState applicationState;

    public PaintCtrlr(InterfaceMode uiModule, IApplicationState applicationState) {
        this.uiModule = uiModule;
        this.applicationState = applicationState;
    }

    @Override
    public void setup() {
        setupEvents();
    }

    private void setupEvents() {
        uiModule.addEvent(EventName.CHOOSE_SHAPE, applicationState::setActiveShape);
        uiModule.addEvent(EventName.CHOOSE_PRIMARY_COLOR, applicationState::setActivePrimaryColor);
        uiModule.addEvent(EventName.CHOOSE_SECONDARY_COLOR, applicationState::setActiveSecondaryColor);
        uiModule.addEvent(EventName.CHOOSE_SHADING_TYPE, () -> applicationState.setActiveShadingType());
        uiModule.addEvent(EventName.ACTIONS, applicationState::setActiveStartAndEndPointMode);
        uiModule.addEvent(EventName.UNDO, new UNDO()::run);
        uiModule.addEvent(EventName.REDO, new REDO()::run);
        uiModule.addEvent(EventName.COPY, new COPY()::run);
        uiModule.addEvent(EventName.PASTE, new PASTE()::run);
        uiModule.addEvent(EventName.DELETE, new DELETE()::run);
    
    }
}
